package com.egiants.rlm.entity;

public enum Gender {
    MALE, FEMALE;

}
