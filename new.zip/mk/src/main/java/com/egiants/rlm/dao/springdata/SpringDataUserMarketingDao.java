package com.egiants.rlm.dao.springdata;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.egiants.rlm.dao.UserMarketingDao;
import com.egiants.rlm.dao.config.DynamoDbConfig;
import com.egiants.rlm.entity.UserMarketing;
import com.egiants.rlm.entity.User;
@Repository
public class SpringDataUserMarketingDao implements UserMarketingDao {
	@Autowired
	DynamoDbConfig dynamoDbConfig;
	@Autowired
	private UserMarketingRepo userMarketingRepo;

	@Override
	public List<UserMarketing> getMarketings() {
		Iterable<UserMarketing> userMarketings = this.userMarketingRepo.findAll();

        return (List<UserMarketing>) userMarketings;
	}

	@Override
	public UserMarketing getMarketing(String date) {
		// TODO Auto-generated method stub
		return this.userMarketingRepo.findBydate(date);
	}

	@Override
	public UserMarketing createMarketing(UserMarketing userMarketing) {
		 return this.userMarketingRepo.save(userMarketing);
	}

	@Override
	public UserMarketing updateMarketing(UserMarketing userMarketing) {
		// TODO Auto-generated method stub
		return this.userMarketingRepo.save(userMarketing);//customUpdate(user);
	}

	@Override
	public void deleteMarketing(String emailId) {
		this.userMarketingRepo.deleteBycontactEmailid(emailId);
		
	}

	@Override
	public List<UserMarketing> getMarketings(String vendorOrganizationName, String implementationPartner) {
		// TODO Auto-generated method stub
		Iterable<UserMarketing> userMarketings = 
				this.userMarketingRepo.findByVendorOrganizationNameAndImplementationPartner(vendorOrganizationName, implementationPartner);

        return (List<UserMarketing>) userMarketings;
	}


	@Override
	public List<UserMarketing> findAllBydate(String date) {
		// TODO Auto-generated method stub
		return this.userMarketingRepo.findAllBydate(date);
	}

	public List<UserMarketing> getMarketingWithDynamicAttribute(UserMarketing searchQuery) {
		return null;
//		// TODO Auto-generated method stub
//		
//		//String var1="findAllBy"; 
//		String var2,var3;
//		  // if(searchQuery.getVendorOrganizationName()!=null)
//		   {			
//			   var2="VendorOrganizationName";
//			   var3=searchQuery.getVendorOrganizationName();  
//			}
//					
////		   else if(searchQuery.getImplementationPartner()!=null)
////			{
////			     return this.userMarketingRepo.findAllByImplementationPartner(searchQuery.getImplementationPartner());
////			}
////					
////			else if(searchQuery.getClient()!=null){
////				
////				return this.userMarketingRepo.findAllByClient(searchQuery.getClient());
////			     
////					}
////					
//////			if(searchQuery.getSubmittedBy()!=null){
//////			     
//////					}
////					
////			else if(searchQuery.getComments()!=null){
////			     
////				return this.userMarketingRepo.findAllByComments(searchQuery.getComments());
////					}
//			
//			return this.userMarketingRepo.findAllBy+"var2"(var3);
	}



	
}
