package com.egiants.rlm.entity;

public enum MaritalStatus {
    SINGLE, MARRIED

}
