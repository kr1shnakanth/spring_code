package com.egiants.rlm.dao;

import java.time.LocalDate;
import java.util.List;

import com.egiants.rlm.entity.UserMarketing;
import com.egiants.rlm.entity.UserMarketing;

public interface UserMarketingDao {

	 

	List<UserMarketing> getMarketings();

    UserMarketing getMarketing(String date);

    List<UserMarketing> findAllBydate(String date);
    List<UserMarketing> getMarketingWithDynamicAttribute(UserMarketing searchQuery);
    
    UserMarketing createMarketing(UserMarketing userMarketing);

    UserMarketing updateMarketing(UserMarketing userMarketing);

    void deleteMarketing(String emailId);

	List<UserMarketing> getMarketings(String vendorOrganizationName, String implementationPartner);

	
}
