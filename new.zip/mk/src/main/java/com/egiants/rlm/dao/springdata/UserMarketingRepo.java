package com.egiants.rlm.dao.springdata;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.DynamoDBCrudRepository;
import org.socialsignin.spring.data.dynamodb.repository.EnableScan;

import com.egiants.rlm.entity.UserMarketing;

@EnableScan
public interface UserMarketingRepo extends DynamoDBCrudRepository<UserMarketing, Integer> {

	Iterable<UserMarketing> findByVendorOrganizationNameAndImplementationPartner(String vendorOrganizationName, String implementationPartner);

	List<UserMarketing> findAllBydate(String date);
	
	UserMarketing findBydate(String date);
	
	void deleteBycontactEmailid(String contactEmailid);
	
	List<UserMarketing> findAllByVendorOrganizationName(String vendorOrganizationName );
	List<UserMarketing> findAllByImplementationPartner(String implementationPartner );
	List<UserMarketing> findAllByClient(String client );
	List<UserMarketing> findAllByComments(String comments);


}

